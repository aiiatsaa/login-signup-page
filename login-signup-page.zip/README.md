# Login & Sign Up Page

This is a simple static website that features a login and sign-up form built using HTML and CSS.

## Features

- Responsive login and sign-up forms
- Simple, clean UI
- Easy to host on GitHub Pages

## Live Demo

You can view the live version here: [https://your-username.github.io/login-signup-page](https://your-username.github.io/login-signup-page)

> Replace `your-username` with your actual GitHub username.

## Usage

To run locally:
1. Clone this repository
2. Open `index.html` in your browser
